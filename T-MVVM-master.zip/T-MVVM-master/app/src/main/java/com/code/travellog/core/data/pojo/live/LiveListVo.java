package com.code.travellog.core.data.pojo.live;


import java.io.Serializable;
import java.util.List;


public class LiveListVo implements Serializable {

    public List<LiveRecommendVo> data;
}
