package com.code.travellog.core.data.pojo.article;

import com.code.travellog.core.data.pojo.BaseVo;

import java.io.Serializable;

public class ArticleListVo extends BaseVo implements Serializable
{
    public ArticleInfoVo data;
}
