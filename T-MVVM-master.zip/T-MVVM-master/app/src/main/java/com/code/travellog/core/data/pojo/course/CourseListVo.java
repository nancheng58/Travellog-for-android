package com.code.travellog.core.data.pojo.course;

import java.util.List;


public class CourseListVo {
    /**
     * errno : 0
     * data : [{"cmtcount":"44","share_desc":"画人物，我觉得必须从几何开始，可以跳过静物，石膏同理，因为可以把人脸分解和统一成基本的几何物体，好像结婚一样，可以先斩后奏的\u2026\u2026我想新手们点字把它读完后，多多少少要有21.333％收获的\u2026\u2026","share_title":"素描是什么东西就不说了，说了也没有用\u2026\u2026\r\n","status":"2","f_catalog_id":"1","share_img":"http://m.meiyuanbang.com/static/images/logo.jpg","teacheruid":"1","hits":"110","title":"111","courseid":"1","s_catalog_id":"101","ctime":"1487063942","hits_basic":"100","desc":"111","thumb_url":"http://m.meiyuanbang.com/static/images/logo.jpg","f_catalog":"色彩","supportcount":"15","s_catalog":"静物单体","video_legth":"30","userinfo":{"genderid":"0","role_type":"1","uid":"1","provinceid":"1","city":"Beijing","school":"CAFA","featureflag":"0","professionid":"5","avatar":"https://img.meiyuanbang.com//user/2015-08-08/B3E75DCC291E3DD4EFF1D044AD3DE533.jpg","sname":"帮叔","intro":"人努力，天帮忙！","ukind_verify":"1","ukind":"1","province":"北京","gender":"男","profession":"老师"}}]
     */
    public List<CourseInfoVo> data;
}
