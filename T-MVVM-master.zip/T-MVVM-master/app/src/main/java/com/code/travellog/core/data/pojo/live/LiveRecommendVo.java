package com.code.travellog.core.data.pojo.live;

import com.code.travellog.core.data.pojo.user.UserInfoVo;

/**
 * @author
 */
public class LiveRecommendVo {
    public String live_thumb_url;
    public String share_img;
    public String s_catalog_id;
    public String cmtcount;
    public String recording_price;
    public String start_time;
    public String live_content;
    public String videoid;
    public String f_catalog_id;
    public String teacher_desc;
    public String hits;
    public String hits_basic;
    public String share_title;
    public String status;
    public String live_price;
    public String supportcount;
    public String adminuid;
    public String live_display_url;
    public String ctime;
    public String live_push_url;
    public String teacheruid;
    public String share_desc;
    public String end_time;
    public String advid;
    public String liveid;
    public String recording_thumb_url;
    public String live_title;
    public String username;
    public String live_sign_count;
    public int live_status;
    public UserInfoVo userinfo;
    public String live_sign_status;
    public LiveInfoVo videoinfo;
    public String buy_status;
    public String live_url;
    public String live_sign_url;
    public int fav;
    public String rtmp_url;
    public int follow_type;
}
