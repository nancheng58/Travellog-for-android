package com.code.travellog.core.data.pojo.banner;


import java.util.List;

public class BannerListVo
{
    public List<BannerVo> data;

    public BannerListVo(List<BannerVo> data) {
        this.data = data;
    }
}
