package com.code.travellog.core.data.pojo.followdraw;

import com.code.travellog.core.data.pojo.BaseVo;

import java.util.List;

public class FollowDrawRecommendVo extends BaseVo {

    public List<FollowDrawInfoVo> data;
}
