package com.code.travellog.core.data.pojo.correct;

import com.code.travellog.core.data.pojo.image.ImageVo;

public class WorkPicVo {
    public String description;

    public String rid;

    public String resource_type;

    public ImageVo img;
}
