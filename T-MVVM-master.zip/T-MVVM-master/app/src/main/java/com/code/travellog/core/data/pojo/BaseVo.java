package com.code.travellog.core.data.pojo;

import java.io.Serializable;

/**
 * @author tqzhang
 */
public class BaseVo implements Serializable {
    public int errno = -1;
}
