package com.code.travellog.core.data.pojo.live;

public class LiveInfoVo {
    public String status;
    public String desc;
    public String coverpic;
    public String m3u8url;
    public String subtype;
    public String filename;
    public String ctime;
    public String maintype;
    public String video_type;
    public String sourceurl;
    public String runid;
    public int video_size;
    public String video_length;
    public String videoid;
}
