package com.code.travellog.core.data.pojo.home;


/**
 * @author：tqzhang on 18/6/20 13:40
 */
public class CategoryVo {

     public String title;

    public CategoryVo(String title) {
        this.title=title;
    }
}
