package com.code.travellog.core.data.pojo.common;

import android.support.annotation.NonNull;

public class TypeVo {
    public @NonNull
    String title;

    public TypeVo(@NonNull final String title) {
        this.title = title;
    }
}
