package com.code.travellog.core.data.pojo.material;

import com.code.travellog.core.data.pojo.image.ImageVo;

public class MatreialSubjectVo {
    public String subjectid;
    public String title;
    public ImageVo picurl;
    public String rids;
    public int hits;
    public int ctime;
    public int status;
    public String stick_date;
    public String subject_typeid;
    public String material_desc;
    public int cmtcount;
    public int supportcount;
}
