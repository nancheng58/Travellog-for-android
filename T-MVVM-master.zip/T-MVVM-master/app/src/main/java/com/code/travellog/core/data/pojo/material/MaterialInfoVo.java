package com.code.travellog.core.data.pojo.material;

import com.code.travellog.core.data.pojo.image.ImageVo;

public class MaterialInfoVo {

    public boolean is_select;
    public String f_catalog;
    public String type;
    public String s_catalog_id;
    public String f_catalog_id;
    public String tid;
    public String ctime;
    public String dtime;
    public String flag;
    public String title;
    public String uid;
    public String content;
    public String utime;
    public String hits;
    public String correctid;
    public String img;
    public String s_catalog;
    public ImageVo imgs;
    public String sname;
    public String avatar;
    public String subjectid;
    public int ukind;
    public String intro;
    public String ukind_verify;
    public String featureflag;
    public String gender;
    public String province;
    public String profession;
}
