package com.code.travellog.core.data.pojo.correct;

import com.code.travellog.core.data.pojo.BaseVo;

public class WorkDetailVo extends BaseVo
{
    public WorkInfoVo data;

}
