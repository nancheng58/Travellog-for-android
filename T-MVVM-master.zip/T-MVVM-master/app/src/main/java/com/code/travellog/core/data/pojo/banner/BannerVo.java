package com.code.travellog.core.data.pojo.banner;

/**
 * @author：tqzhang  on 18/5/8 15:40
 */
public class BannerVo {
    public String imgUrl;
    public String advid;
    public String channelid;
    public String typeid;
    public String topimage1;
    public String param1;
    public String param2;
    public String param3;
    public String param4;
    public String param5;
    public String listorder;
    public String status;
    public String hits;
    public String clickcount;
    public String advuid;
    public String ctime;
    public String topimage2;
    public String topimage;
}
