package com.code.travellog.core.view.course;

import android.os.Bundle;

import com.mvvm.base.BaseFragment;


/**
 * @author：tqzhang on 18/7/16 16:58
 */
public class AboutCourseFragment extends BaseFragment {
    @Override
    public int getLayoutResId() {
        return 0;
    }

    @Override
    public int getContentResId() {
        return 0;
    }

    @Override
    public void initView(Bundle state) {

    }

    @Override
    protected void onStateRefresh() {

    }
}
