package com.code.travellog.core.data.pojo.home;

import com.code.travellog.core.data.pojo.banner.BannerListVo;

/**
 * @author：tqzhang on 18/8/31 10:25
 */
public class HomeMergeVo {
    public BannerListVo bannerListVo;
    public HomeListVo homeListVo;
}
