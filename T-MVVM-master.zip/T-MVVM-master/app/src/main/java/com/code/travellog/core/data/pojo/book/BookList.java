package com.code.travellog.core.data.pojo.book;


import java.util.List;

public class BookList {
    public List<BookVo> publishingbook;

    public BookList(List<BookVo> publishingbook) {
        this.publishingbook=publishingbook;
    }
}
