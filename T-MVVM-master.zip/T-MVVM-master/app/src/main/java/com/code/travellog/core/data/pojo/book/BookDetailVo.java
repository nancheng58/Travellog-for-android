package com.code.travellog.core.data.pojo.book;

import com.code.travellog.core.data.pojo.BaseVo;

import java.io.Serializable;

public class BookDetailVo extends BaseVo implements Serializable
{

}
