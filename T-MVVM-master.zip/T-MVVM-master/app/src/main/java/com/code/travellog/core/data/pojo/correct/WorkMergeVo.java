package com.code.travellog.core.data.pojo.correct;

import com.code.travellog.core.data.pojo.banner.BannerListVo;

/**
 * @author：tqzhang on 18/8/31 11:06
 */
public class WorkMergeVo {

    public BannerListVo bannerListVo;

    public WorksListVo worksListVo;

    public WorkDetailVo workDetailVo;

    public WorkRecommentVo workRecommentVo;
}
