package com.code.travellog.core.data.pojo.dynamic;

import java.util.ArrayList;

public class DynamicListVo
{
    public ArrayList<DynamicInfoVo> data;

}
