package com.live;

import android.os.Bundle;

import com.basiclibrary.base.BaseActivity;

/**
 * @author：tqzhang on 18/5/2 15:28
 */
public class LiveActivity extends BaseActivity {
    @Override
    public int getLayoutId() {
        return 0;
    }

    @Override
    public void initViews(Bundle savedInstanceState) {

    }
}
